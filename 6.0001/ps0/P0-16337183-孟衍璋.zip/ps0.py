import math
x = input("Enter number x:")
y = input("Enter number y:")
print("x**y =", int(x)**int(y))
print("log(x) =", math.log(int(x), 2))